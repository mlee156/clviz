from clarityviz import clarityviz 

version = "0.0.1"
